! function() {
    function e() {
        var e = UserWayWidgetApp.ContextHolder.config,
            t = e._userway_config.hasOwnProperty("ai_custom_focus_style_enabled");
        return t ? t && (!0 === e._userway_config.ai_custom_focus_style_enabled || "true" === e._userway_config.ai_custom_focus_style_enabled) : c.enabled
    }

    function t(e) {
        var t = {
            outline: c.outlineWidth + " " + c.outlineStyle + " " + c.outlineColor
        };
        return t["outline-offset"] = "-" + c.outlineWidth, t
    }

    function n(e) {
        if ("function" == typeof e.hasAttribute && e.hasAttribute(m)) {
            var n = window.getComputedStyle(e),
                r = t(n);
            f.resetInlineStyles(e, m, r), e.removeAttribute(m)
        }
    }

    function r(e) {
        e.target && y && s.addStyles(e.target)
    }

    function i(e) {
        var t = e ? "addEventListener" : "removeEventListener";
        document[t]("mousedown", o), document[t]("keydown", a), document[t]("focusin", r), document[t]("focusout", g)
    }

    function o() {
        y = !1
    }

    function a() {
        y = !0
    }
    var u, l, d;
    if (!(null === (d = null === (l = null === (u = UserWayWidgetApp.ContextHolder) || void 0 === u ? void 0 : u.config) || void 0 === l ? void 0 : l.tunings) || void 0 === d ? void 0 : d.new_focus_rule)) {
        var s = UserWayWidgetApp.addLib("REMEDIATION_FOCUS_STYLE"),
            c = UserWayWidgetApp.getLib("remediationConfig").customFocus,
            f = UserWayWidgetApp.getLib("inlineStyling"),
            p = UserWayWidgetApp.getLib("remediation_utils"),
            m = "data-uw-rm-outline",
            h = {
                width: "2px",
                color: " #0018FF",
                style: "solid"
            },
            y = !1;
        s.apply = function() {
            var t, n, r, o;
            if (e()) {
                var a = null === (r = null === (n = null === (t = UserWayWidgetApp.ContextHolder) || void 0 === t ? void 0 : t.config) || void 0 === n ? void 0 : n.tunings) || void 0 === r ? void 0 : r.widget_color,
                    u = null === (o = UserWayWidgetApp.getLib("remediationConfig").customFocus.config) || void 0 === o ? void 0 : o.style,
                    l = "string" == typeof u ? JSON.parse(u) : u || h;
                c.outlineWidth = l.width, c.outlineColor = l.color || a, c.outlineStyle = l.style, setTimeout(function() {
                    i(!0)
                }, 500)
            }
        }, s.getFocusStyle = function() {
            return {
                enabled: e(),
                outlineWidth: c.outlineWidth || h.width,
                outlineColor: c.outlineColor || h.color,
                outlineStyle: c.outlineStyle || h.style
            }
        }, s.updateOutlineStyle = function(e) {
            if (e.data && (e.data.update || null != e.data.enabled)) {
                var t = e.data.update,
                    r = e.data.enabled;
                c.outlineWidth = t.width, c.outlineStyle = t.style, c.outlineColor = t.color, i(r), c.enabled !== r && ([].slice.call(document.querySelectorAll("[" + m + "]")).forEach(function(e) {
                    n(e)
                }), c.enabled = r)
            }
        }, s.addStyles = function(e) {
            if (!e.hasAttribute(p.ignoreElementFromHelperProcessingAttr)) {
                var n = window.getComputedStyle(e),
                    r = t(n);
                f.applyInlineStyles(e, m, r), e.setAttribute(m, "")
            }
        };
        var g = function(e) {
            e.target && n(e.target)
        }
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, i, o = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = o.next()).done;) a.push(r.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = o.return) && n.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, i = 0, o = t.length; i < o; i++) !r && i in t || (r || (r = Array.prototype.slice.call(t, 0, i)), r[i] = t[i]);
        return e.concat(r || Array.prototype.slice.call(t))
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    function e(e) {
        return e.filter(function(e) {
            var t, n, r, o, m, h, y, g;
            if ("function" == typeof e.hasAttribute && e.hasAttribute(u) || a.isInertElement(e) || !i.isElementVisible(e, {
                    shouldBeInViewport: !1
                }) || a.isNativeTabbableElement(e) || a.isAriaHiddenElement(e) || a.hasTabbableDescendants(e)) return !1;
            if (e.classList && e.classList.contains("betterbot_botInfoText")) return e.setAttribute(u, l.BETTERBOT_CHAT), !0;
            if ("function" == typeof e.getAttribute && d.indexOf(e.getAttribute("role")) > -1 && !e.hasAttribute("tabindex")) return e.setAttribute(u, l.HAS_ROLE_NO_TABINDEX), !0;
            var v = !1,
                b = !1;
            if ("function" == typeof e.hasAttribute) try {
                for (var A = __values(s), _ = A.next(); !_.done; _ = A.next()) {
                    var E = _.value;
                    if (e.hasAttribute(E) && !i.isElementEditable(e)) {
                        b = !1, v = !0;
                        try {
                            for (var w = (r = void 0, __values(c)), S = w.next(); !S.done; S = w.next()) {
                                var x = S.value;
                                e.hasAttribute(x) && (b = !0)
                            }
                        } catch (e) {
                            r = {
                                error: e
                            }
                        } finally {
                            try {
                                S && !S.done && (o = w.return) && o.call(w)
                            } finally {
                                if (r) throw r.error
                            }
                        }
                    }
                }
            } catch (e) {
                t = {
                    error: e
                }
            } finally {
                try {
                    _ && !_.done && (n = A.return) && n.call(A)
                } finally {
                    if (t) throw t.error
                }
            }
            if (v && !b) return e.setAttribute(u, l.HAS_ONCLICK_NO_ONKEYPRESS), !0;
            var W = !1,
                O = !1,
                C = !1,
                k = ["drag-and-drop"];
            if ("function" == typeof e.hasAttribute) {
                C = e.hasAttribute("tabindex");
                try {
                    for (var N = __values(f), P = N.next(); !P.done; P = N.next()) {
                        var E = P.value;
                        if (k.indexOf(e.nodeName.toLowerCase()) < 0 && e.hasAttribute(E) && !i.isElementEditable(e)) {
                            O = !1, W = !0;
                            try {
                                for (var L = (y = void 0, __values(p)), R = L.next(); !R.done; R = L.next()) {
                                    var x = R.value;
                                    e.hasAttribute(x) && (O = !0)
                                }
                            } catch (e) {
                                y = {
                                    error: e
                                }
                            } finally {
                                try {
                                    R && !R.done && (g = L.return) && g.call(L)
                                } finally {
                                    if (y) throw y.error
                                }
                            }
                        }
                    }
                } catch (e) {
                    m = {
                        error: e
                    }
                } finally {
                    try {
                        P && !P.done && (h = N.return) && h.call(N)
                    } finally {
                        if (m) throw m.error
                    }
                }
            }
            return !W || O || C ? !("A" !== e.tagName || e.href || e.hasAttribute("tabindex") || e.hasAttribute("role")) && (e.setAttribute(u, l.ANCHOR_NO_HREF), !0) : (e.setAttribute(u, l.HAS_NGCLICK_NO_NGKEYPRESS), !0)
        })
    }

    function t(e, t, n, o, a) {
        try {
            e.onHelperRemediationStarted("REMEDIATION_KEYBOARD_NAVIGATION");
            var d = 0;
            o.forEach(function(e) {
                var t = e.getAttribute(u);
                if (t) return d++, t === l.BETTERBOT_CHAT ? (e.setAttribute("tabindex", "0"), e.setAttribute("role", "button"), e.setAttribute("aria-label", "Start chat with us"), void i.clickOnEnter(e)) : t === l.HAS_ROLE_NO_TABINDEX ? (e.setAttribute("tabindex", "0"), void i.clickOnEnter(e)) : t === l.OVERFLOW_HELPER ? void e.setAttribute("tabindex", "0") : t === l.HAS_ONCLICK_NO_ONKEYPRESS ? void i.clickOnEnter(e) : t && e.getAttribute(u) === l.HAS_NGCLICK_NO_NGKEYPRESS ? (e.setAttribute("role", "button"), e.setAttribute("tabindex", "0"), void i.clickOnEnter(e)) : t === l.ANCHOR_NO_HREF ? (e.setAttribute("tabindex", "0"), void("pointer" === window.getComputedStyle(e).cursor && i.clickOnEnter(e))) : void 0
            }), e.onHelperRemediationCompleted(r.of("REMEDIATION_KEYBOARD_NAVIGATION", null, null, d, 0)), t()
        } catch (e) {
            n(e)
        }
    }
    var n = UserWayWidgetApp.addLib("REMEDIATION_KEYBOARD_NAVIGATION"),
        r = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        i = UserWayWidgetApp.getLib("remediation_util"),
        o = UserWayWidgetApp.getLib("util"),
        a = UserWayWidgetApp.getLib("remediation_utils"),
        u = "data-uw-rm-kbnav",
        l = {
            BETTERBOT_CHAT: "betterbot",
            HAS_ROLE_NO_TABINDEX: "role",
            HAS_ONCLICK_NO_ONKEYPRESS: "click",
            HAS_NGCLICK_NO_NGKEYPRESS: "ngclick",
            OVERFLOW_HELPER: "scrollTabIndex",
            ANCHOR_NO_HREF: "anohref"
        },
        d = ["link", "button", "menuitem", "checkbox"],
        s = ["onclick"],
        c = ["onkeydown", "onkeyup", "onkeypress"],
        f = ["ng-click"],
        p = ["ng-keypress", "ng-keyup", "ng-keydown"];
    n.filter = function(t, n) {
        return n.reset, e([].concat.apply([], __spreadArray([], __read(t.map(function(e) {
            return [].slice.call(o.findAllElements(e))
        })), !1)))
    }, n.awaitForResources = function(e, t) {
        return Promise.resolve()
    }, n.doRemediation = function(e, n, r) {
        return new Promise(function(i, o) {
            t(e, i, o, n, r)
        })
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, i, o = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = o.next()).done;) a.push(r.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = o.return) && n.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, i = 0, o = t.length; i < o; i++) !r && i in t || (r || (r = Array.prototype.slice.call(t, 0, i)), r[i] = t[i]);
        return e.concat(r || Array.prototype.slice.call(t))
    };
! function() {
    var e = UserWayWidgetApp.addLib("REMEDIATION_POPUP"),
        t = UserWayWidgetApp.getLib("remediation_util"),
        n = UserWayWidgetApp.getLib("event_emitter"),
        r = UserWayWidgetApp.getLib("util");
    e.apply = function() {
        n.on("UW_CER_POPUP_ON", function(e) {
            var n = __read(e, 2),
                i = n[0],
                o = n[1];
            ! function(e, n) {
                setTimeout(function() {
                    var i, o;
                    t.clickOnEnter(n);
                    var a = Array.from(e.querySelectorAll(t.focusableElementsSelector)).filter(function(e) {
                        return n !== e && t.isElementVisible(e, {
                            skipParentCheck: !0
                        }) && !e.hasAttribute("data-uw-rm-ignore")
                    });
                    try {
                        for (var u = __values(a), l = u.next(); !l.done; l = u.next()) {
                            var d = l.value;
                            d.setAttribute("tabindex", "0"), t.clickOnEnter(d)
                        }
                    } catch (e) {
                        i = {
                            error: e
                        }
                    } finally {
                        try {
                            l && !l.done && (o = u.return) && o.call(u)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                    if (a.length) {
                        null === n || void 0 === n || n.setAttribute("tabindex", "0");
                        var s = n ? __spreadArray([n], __read(a), !1) : a;
                        t.trapFocusPopupElements(s, e)
                    } else n && (n.addEventListener("keydown", function(e) {
                        t.keys.isTab(e) && e.preventDefault()
                    }), n.focus());
                    if (e.addEventListener("keydown", function(e) {
                            t.keys.isEsc(e) && n.click()
                        }), n) {
                        r.customTrim(n.textContent).length < 3 && !n.hasAttribute("aria-label") && !n.hasAttribute("aria-labelledby") && n.setAttribute("aria-label", "Close dialog"), -1 !== ["INPUT", "BUTTON", "A"].indexOf(n.tagName) || n.hasAttribute("role") || (n.setAttribute("role", "button"), n.setAttribute("tabindex", "0"))
                    }
                }, 1e3)
            }(i, o)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t = Array.from(e.children),
            n = t.filter(function(e) {
                return "LI" === e.tagName && !e.hasAttribute("role")
            });
        if (n.length) return n;
        var r = t.filter(function(e) {
            return !e.hasAttribute("role") && (["A", "BUTTON"].includes(e.tagName) || e.hasAttribute("tabindex"))
        });
        return r.length ? r : []
    }

    function t() {
        var t, n, r = 0,
            i = Array.from(document.querySelectorAll('*[role="menu"], *[role="menubar"]'));
        try {
            for (var o = __values(i), a = o.next(); !a.done; a = o.next()) {
                var u = a.value;
                ! function(t) {
                    var n, i;
                    if (!t.hasAttribute(p)) {
                        t.setAttribute(p, "");
                        if (!Array.from(t.querySelectorAll('*[role="menuitem"], *[role="menuitemcheckbox"], *[role="menuitemradio"]')).length) {
                            r++;
                            var o = e(t);
                            try {
                                for (var a = (n = void 0, __values(o)), u = a.next(); !u.done; u = a.next()) {
                                    var l = u.value;
                                    l.setAttribute("role", "menuitem"), l.setAttribute(p, "menuitem")
                                }
                            } catch (e) {
                                n = {
                                    error: e
                                }
                            } finally {
                                try {
                                    u && !u.done && (i = a.return) && i.call(a)
                                } finally {
                                    if (n) throw n.error
                                }
                            }
                            if (!o.length && !c.isElementVisible(t, {
                                    shouldBeInViewport: !1
                                })) {
                                var d = t.getAttribute("role");
                                t.setAttribute(p + "-role", d), t.removeAttribute("role"), c.onElementVisible(t, function() {
                                    if (t.hasAttribute(p + "-role")) {
                                        var e = t.getAttribute(p + "-role");
                                        t.removeAttribute(p + "-role"), t.setAttribute("role", e)
                                    }
                                })
                            }
                        }
                    }
                }(u)
            }
        } catch (e) {
            t = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (n = o.return) && n.call(o)
            } finally {
                if (t) throw t.error
            }
        }
        return r
    }

    function n() {
        r("aria-labelledby"), r("aria-describedby")
    }

    function r(e) {
        Array.from(document.querySelectorAll("*[" + p + "-" + e + "]")).forEach(function(t) {
            var n = t.getAttribute(p + "-" + e).split(" "),
                r = [],
                i = [];
            n.forEach(function(e) {
                document.getElementById(e) ? r.push(e) : i.push(e)
            }), r.length && t.setAttribute(e, r.join(" ")), i.length ? i.length !== n.length && t.setAttribute(p + "-" + e, i.join(" ")) : t.removeAttribute(p + "-" + e)
        })
    }

    function i() {
        var e = 0;
        return e += o("aria-labelledby"), e += o("aria-describedby")
    }

    function o(e) {
        var t = 0;
        return Array.from(document.querySelectorAll("*[" + e + "]")).forEach(function(n) {
            if (!n.hasAttribute(p)) {
                var r = n.getAttribute(e).split(" "),
                    i = [],
                    o = [];
                r.forEach(function(e) {
                    document.getElementById(e) ? i.push(e) : o.push(e)
                }), o.length && (n.setAttribute(p + "-" + e, o.join(" ")), i.length ? n.setAttribute(e, i.join(" ")) : n.removeAttribute(e)), t += o.length
            }
        }), t
    }

    function a(e) {
        var t = e.tagName.toLowerCase();
        if ("s" === t || "strike" === t || "del" === t) return !0;
        var n = window.getComputedStyle(e);
        if (!!n.getPropertyValue("text-decoration") && n.getPropertyValue("text-decoration").indexOf("line-through") > -1) return !0;
        var r = e.parentElement;
        return !(!r || "BODY" === r.tagName.toUpperCase()) && a(r)
    }

    function u() {
        var e, t, n = 0,
            r = ["NOSCRIPT", "SCRIPT", "style"],
            i = f.ElementsWithText.getElementsWithText(document, !1),
            o = i.filter(function(e) {
                return !r.includes(e.tagName)
            }),
            u = ["CAPTION", "CODE", "EM", "SUP", "SUB", "INS", "P", "STRONG", "B", "MARK", "I", "U", "CITE", "SUGGESTION", "TERM", "TIME", "SPAN", "DIV", "STRIKE", "S", "DEL"],
            l = ["caption", "code", "emphasis", "superscript", "subscript", "insertion", "paragraph", "strong", "mark", "suggestion", "term", "time", "presentation", "none"];
        try {
            for (var d = __values(o), s = d.next(); !s.done; s = d.next()) {
                var m = s.value;
                if (!m.hasAttribute(p)) {
                    var h = c.customTrim(m.innerText),
                        y = h.match(/(?:[\$\xA2-\xA5\u058F\u060B\u09F2\u09F3\u09FB\u0AF1\u0BF9\u0E3F\u17DB\u20A0-\u20BD\uA838\uFDFC\uFE69\uFF04\uFFE0\uFFE1\uFFE5\uFFE6])(?:[^0-9.]*)([\d,.]+)/);
                    h && y && y.length && (m.setAttribute(p, ""), a(m) && (m.setAttribute("aria-label", "Previous price was " + y[0]), function(e) {
                        var t = e.tagName,
                            n = e.getAttribute("role");
                        return u.includes(t) || l.includes(n)
                    }(m) && m.setAttribute("role", "img"), m.setAttribute(p, "price"), n++))
                }
            }
        } catch (t) {
            e = {
                error: t
            }
        } finally {
            try {
                s && !s.done && (t = d.return) && t.call(d)
            } finally {
                if (e) throw e.error
            }
        }
        return n
    }

    function l() {
        m() && [].slice.call(document.querySelectorAll("[" + p + "]")).forEach(function(e) {
            e.removeAttribute(p)
        })
    }
    var d = UserWayWidgetApp.addLib("REMEDIATION_SCREEN_READER_BASIC"),
        s = UserWayWidgetApp.getLib("remediation_helper_outcome"),
        c = UserWayWidgetApp.getLib("util"),
        f = UserWayWidgetApp.getLib("helpers"),
        p = "data-uw-rm-sr",
        m = function() {
            var e, t, n, r = !(null === (n = null === (t = null === (e = UserWayWidgetApp.ContextHolder) || void 0 === e ? void 0 : e.config) || void 0 === t ? void 0 : t.tunings) || void 0 === n ? void 0 : n.new_screen_reader_rem),
                i = function() {
                    var e, t, n, r, i, o, a, u = null === (t = null === (e = UserWayWidgetApp.ContextHolder) || void 0 === e ? void 0 : e.config) || void 0 === t ? void 0 : t.remediation,
                        l = null === (r = null === (n = UserWayWidgetApp.ContextHolder) || void 0 === n ? void 0 : n.config) || void 0 === r ? void 0 : r.services,
                        d = (null === (i = UserWayWidgetApp.ContextHolder) || void 0 === i ? void 0 : i.config).isMobile;
                    if (!(null === l || void 0 === l ? void 0 : l.paidAi)) return !0;
                    var s = u && u.REMEDIATION_SCREEN_READER_BASIC;
                    if (!s) return !0;
                    var c = !1 !== (null === (a = null === (o = s.config) || void 0 === o ? void 0 : o.mobile) || void 0 === a ? void 0 : a.enabled);
                    return s.enabled && (!d || c)
                }();
            return r && i
        };
    d.filter = function(e, t) {
        return t.reset && l(), []
    }, d.awaitForResources = function() {
        return Promise.resolve()
    }, d.doRemediation = function(e) {
        return new Promise(function(r, o) {
            if (m()) try {
                e.onHelperRemediationStarted("REMEDIATION_SCREEN_READER_BASIC");
                var a = u();
                n();
                var l = i(),
                    d = t();
                e.onHelperRemediationCompleted(s.of("REMEDIATION_SCREEN_READER_BASIC", null, null, a + l + d, 0)), r(!0)
            } catch (e) {
                o(e)
            } else r(!1)
        })
    }
}();
var __assign = this && this.__assign || function() {
        return __assign = Object.assign || function(e) {
            for (var t, n = 1, r = arguments.length; n < r; n++) {
                t = arguments[n];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }, __assign.apply(this, arguments)
    },
    __values = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator,
            n = t && e[t],
            r = 0;
        if (n) return n.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && r >= e.length && (e = void 0), {
                    value: e && e[r++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
! function() {
    var e = UserWayWidgetApp.addLib("remediation_util"),
        t = UserWayWidgetApp.getLib("util");
    e.focusableElementsSelector = '\n    a[href]:not([tabindex^="-"], [inert], [hidden]), \n    area[href]:not([tabindex^="-"], [inert], [hidden]), \n    audio[controls]:not([tabindex^="-"], [inert], [hidden]), \n    button:not([disabled], [tabindex^="-"], [inert], [hidden]), \n    details:not([inert], [hidden]) summary:not([tabindex^="-"], [inert], [hidden]), \n    input:not([disabled], [type="hidden"], [tabindex^="-"], [hidden]), \n    iframe:not([tabindex^="-"], [inert], [hidden]), \n    select:not([disabled], [tabindex^="-"], [inert], [hidden]), \n    textarea:not([disabled], [tabindex^="-"], [inert], [hidden]), \n    video[controls]:not([tabindex^="-"], [inert], [hidden]), \n    map[name] area[href]:not([tabindex^="-"]),\n    [tabindex]:not([tabindex^="-"], [inert], [hidden]), \n    [contenteditable]:not([contenteditable="false"], [tabindex^="-"], [inert], [hidden])\n  ', e.keys = {
        isRightShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftRight" === e.code
        },
        isLeftShift: function(e) {
            return 16 === e.keyCode || "Shift" === e.key || "ShiftLeft" === e.code
        },
        isSpace: function(e) {
            return 32 === e.keyCode || " " === e.key || "Space" === e.code
        },
        isEnter: function(e) {
            return 13 === e.keyCode || "Enter" === e.key || "Enter" === e.code
        },
        isEsc: function(e) {
            return 27 === e.keyCode || "Escape" === e.key || "Escape" === e.code
        },
        isTab: function(e) {
            return 9 === e.keyCode || "Tab" === e.key || "Tab" === e.code
        },
        isHome: function(e) {
            return 36 === e.keyCode || "Home" === e.key || "Home" === e.code
        },
        isEnd: function(e) {
            return 35 === e.keyCode || "End" === e.key || "End" === e.code
        },
        isPageUp: function(e) {
            return 33 === e.keyCode || "PageUp" === e.key || "PageUp" === e.code
        },
        isPageDown: function(e) {
            return 34 === e.keyCode || "PageDown" === e.key || "PageDown" === e.code
        },
        isArrowLeft: function(e) {
            return 37 === e.keyCode || "ArrowLeft" === e.key || "ArrowLeft" === e.code
        },
        isArrowUp: function(e) {
            return 38 === e.keyCode || "ArrowUp" === e.key || "ArrowUp" === e.code
        },
        isArrowRight: function(e) {
            return 39 === e.keyCode || "ArrowRight" === e.key || "ArrowRight" === e.code
        },
        isArrowDown: function(e) {
            return 40 === e.keyCode || "ArrowDown" === e.key || "ArrowDown" === e.code
        },
        isPrintableChar: function(e) {
            return 1 === e.key.length && e.key.match(/\S/)
        }
    }, e.log = function(e, t, n) {
        console.warn("UserWay remediation " + e + " - " + t + ": " + n)
    }, e.generateRandomId = t.generateRandomId, e.isElementEditable = function(e) {
        function t(e) {
            var t = e.nodeName.toLowerCase();
            return !!e.hasAttribute("contenteditable") || 1 === e.nodeType && ("textarea" === t || "input" === t && /^(?:text|email|number|search|tel|url|password)$/i.test(e.type))
        }
        var n, r, i = t(e);
        if (i) return !0;
        try {
            for (var o = __values(Array.from(e.querySelectorAll("*"))), a = o.next(); !a.done; a = o.next()) {
                if (i = t(a.value)) break
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = o.return) && r.call(o)
            } finally {
                if (n) throw n.error
            }
        }
        return i
    }, e.waitUntil = function(e, t, n, r) {
        void 0 === n && (n = null), void 0 === r && (r = null), n = __assign({
            timeout: 8e3,
            frequency: 1e3
        }, n || {});
        var i = Date.now();
        ! function o() {
            var a = e();
            if (a) return t(a);
            setTimeout(function() {
                if (n.timeout && Date.now() - i > n.timeout) return void(r && r());
                o()
            }, n.frequency)
        }()
    }, e.trapFocusBetweenElements = function(t, n, r) {
        void 0 === r && (r = null);
        var i = !1;
        window.addEventListener("keydown", function(t) {
            e.keys.isLeftShift(t) && (i = !0)
        }), window.addEventListener("keyup", function(t) {
            e.keys.isLeftShift(t) && (i = !1)
        }), t.setAttribute("tabindex", "0"), document.activeElement && r.contains(document.activeElement) || t.focus(), t.addEventListener("keydown", function(t) {
            e.keys.isTab(t) && i && (t.preventDefault(), n.focus())
        }), n.setAttribute("tabindex", "0"), n.addEventListener("keydown", function(n) {
            e.keys.isTab(n) && (i || (n.preventDefault(), t.focus()))
        })
    }, e.trapFocusPopupElements = function(t, n) {
        void 0 === n && (n = null);
        var r = !1;
        window.addEventListener("keydown", function(t) {
            e.keys.isLeftShift(t) && (r = !0)
        }), window.addEventListener("keyup", function(t) {
            e.keys.isLeftShift(t) && (r = !1)
        });
        var i = t[0],
            o = t[t.length - 1];
        document.activeElement && n.contains(document.activeElement) || i.focus(), t.forEach(function(n, a) {
            n.addEventListener("keydown", function(n) {
                e.keys.isTab(n) && (n.preventDefault(), r ? (t[a - 1] ? t[a - 1] : o).focus() : (t[a + 1] ? t[a + 1] : i).focus())
            })
        })
    }, e.trapFocusBetween = function(e) {
        function t(e, t, r) {
            if (9 === r.keyCode) return n ? t && t.focus() : e && e.focus(), r.preventDefault();
            16 === r.keyCode && (n = !0)
        }
        for (var n = !1, r = [], i = 0; i < e.length; i++) {
            var o = document.querySelector(e[i]);
            if (o) {
                o.setAttribute("tabindex", 0);
                var a = document.querySelector(e[i + 1]) || document.querySelector(e[0]),
                    u = document.querySelector(e[i - 1]) || document.querySelector(e[e.length - 1]),
                    l = t.bind(event, a, u);
                r.push(l), o.addEventListener("keydown", l, !1), o.addEventListener("keyup", function(e) {
                    16 === e.keyCode && (n = !1)
                })
            }
        }
        return setTimeout(function() {
            var t = document.querySelector(e[0]);
            t && t.focus()
        }, 100), {
            terminate: function() {
                for (var t = 0; t < e.length; t++) {
                    document.querySelector(e[t]).removeEventListener("keydown", r[t])
                }
            }
        }
    }, e.waitForDocumentReady = function(e) {
        var t = setInterval(function() {
            "complete" === document.readyState && (clearInterval(t), e())
        }, 10)
    }, e.injectStylesheet = function(e) {
        var t = document.createElement("style");
        return t.innerHTML = e, document.head.appendChild(t), t
    }, e.setSrOnly = function(e) {
        if (e.style) {
            var t = {
                overflow: "hidden",
                position: "absolute",
                margin: "0",
                padding: "0",
                width: "1px",
                height: "1px",
                border: "0",
                clip: "rect(1px, 1px, 1px, 1px)",
                "-webkit-clip-path": "inset(50%)",
                "clip-path": "inset(50%)",
                "white-space": "nowrap"
            };
            for (var n in t) e.style.setProperty(n, t[n], "important")
        }
    }, e.createSrOnlyElement = function(t, n) {
        void 0 === t && (t = ""), void 0 === n && (n = "span");
        var r = document.createElement(n);
        return r.textContent = t, e.setSrOnly(r), r
    }, e.isElementVisible = function(e, t) {
        t = t || {}, t.hasOwnProperty("skipParentCheck") || (t.skipParentCheck = !1), t.hasOwnProperty("shouldBeInViewport") || (t.shouldBeInViewport = !0);
        var n = function(e, t) {
                if (!e) return !1;
                if (e === document) return !0;
                var n = getComputedStyle(e),
                    r = e.getBoundingClientRect(),
                    i = r.top >= 0 && r.left >= 0 && r.bottom <= (window.innerHeight || document.documentElement.clientHeight) && r.right <= (window.innerWidth || document.documentElement.clientWidth),
                    o = 0 === r.width || 0 === r.height;
                return (e.offsetWidth > 0 || e.offsetHeight > 0 || e.getClientRects().length > 0) && (!t.shouldBeInViewport || i) && !o && "0" !== n.opacity && "hidden" !== n.visibility && "collapse" !== n.visibility
            },
            r = n(e, t);
        if (!t.skipParentCheck)
            for (; r && e.parentNode && e.parentNode !== document;) n(e.parentNode, {
                shouldBeInViewport: !1
            }) ? e = e.parentNode : r = !1;
        return r
    }, e.fireEvent = function(e, t) {
        if (e.fireEvent) e.fireEvent("on" + t);
        else {
            var n = document.createEvent("Events");
            n.initEvent(t, !0, !1), e.dispatchEvent(n)
        }
    }, e.clickOnEnter = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(n) {
            e.keys.isEnter(n) && (n.preventDefault(), t.click())
        })
    }, e.clickOnSpace = function(t) {
        t && "function" == typeof t.click && !e.isElementEditable(t) && t.addEventListener("keydown", function(n) {
            e.keys.isSpace(n) && (n.preventDefault(), t.click())
        })
    }, e.execOnPage = function(e, t) {
        var n, r, i;
        if (Array.isArray(e)) try {
            for (var o = __values(e), a = o.next(); !a.done; a = o.next()) {
                var u = a.value;
                if (i = new RegExp(u).test(window.location.href)) {
                    t();
                    break
                }
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = o.return) && r.call(o)
            } finally {
                if (n) throw n.error
            }
        } else(i = new RegExp(e).test(window.location.href)) && t();
        return i
    }, e.getFocusableElement = function(t, n, r) {
        t = t || "next", r = r || {}, r.childrenOnly = r.childrenOnly || !1, r.canBeHidden = r.canBeHidden || !1;
        var i = Array.from((r.childrenOnly ? n : document).querySelectorAll(e.focusableElementsSelector + (n ? "," + e.getCssPath(n) : "")));
        r.canBeHidden || (i = i.filter(function(e) {
            return !!e.offsetParent
        }));
        var o = i.findIndex(function(e) {
            return !(!n || e !== n) || e === document.activeElement
        });
        return "next" === t ? i[o + 1] || i[0] : "prev" === t ? i[o - 1] || i[i.length - 1] : void 0
    }, e.getCssPath = function(e) {
        for (var t = []; e.parentNode;) {
            if (e.id) {
                t.unshift("#" + e.id);
                break
            }
            if (e == e.ownerDocument.documentElement) t.unshift(e.tagName);
            else {
                for (var n = 1, r = e; r.previousElementSibling; r = r.previousElementSibling, n++);
                t.unshift(e.tagName + ":nth-child(" + n + ")")
            }
            e = e.parentNode
        }
        return t.join(" > ")
    }, e.getElementPosition = function(e) {
        for (var t = 0, n = 0; e;) {
            if ("BODY" == e.tagName) {
                var r = e.scrollLeft || document.documentElement.scrollLeft,
                    i = e.scrollTop || document.documentElement.scrollTop;
                t += e.offsetLeft - r + e.clientLeft, n += e.offsetTop - i + e.clientTop
            } else t += e.offsetLeft - e.scrollLeft + e.clientLeft, n += e.offsetTop - e.scrollTop + e.clientTop;
            e = e.offsetParent
        }
        return {
            x: t,
            y: n
        }
    };
    var n = [];
    e.onHistoryPushState = function(e, t) {
        if (void 0 === t && (t = {}), t = __assign({
                delay: 300
            }, t), n.push(e), 1 === n.length) {
            if (window.history) {
                var r = window.history.pushState;
                window.history.pushState = function(e) {
                    return "function" == typeof window.history.onpushstate && window.history.onpushstate({
                        state: e
                    }), r.apply(window.history, arguments)
                }
            }
            var i;
            window.onpopstate = window.history.onpushstate = function() {
                clearTimeout(i), i = setTimeout(function() {
                    return n.forEach(function(e) {
                        return e()
                    })
                }, t.delay)
            }
        }
    }, e.announce = function(e) {
        var t = document.createElement("div");
        t.setAttribute("aria-live", "assertive"), t.style.width = "0", t.style.height = "0", t.style.overflow = "hidden", document.body.insertAdjacentElement("afterbegin", t), setTimeout(function() {
            t.innerHTML = e
        }, 1e3), setTimeout(function() {
            t.remove()
        }, 1e4)
    }, e.queryXPath = function(e, t) {
        var n;
        void 0 === t && (t = null);
        var r = document.evaluate(e, t || document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
        return (null === r || void 0 === r ? void 0 : r.singleNodeValue) && (null === (n = null === r || void 0 === r ? void 0 : r.singleNodeValue) || void 0 === n ? void 0 : n.nodeType) === Node.ELEMENT_NODE ? r.singleNodeValue : null
    }, e.queryXPathAll = function(e, t) {
        void 0 === t && (t = null);
        for (var n = document.evaluate(e, t || document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null), r = [], i = 0, o = n.snapshotLength; i < o; ++i) r.push(n.snapshotItem(i));
        return r
    }, e.loopThroughElements = function(t, n, r, i) {
        void 0 === r && (r = null), void 0 === i && (i = null), r = __assign({
            ancestor: document,
            useForEach: !0
        }, r || {}), e.waitUntil(function() {
            if (r.ancestor) {
                var n = [];
                try {
                    n = r.ancestor.querySelectorAll(t)
                } catch (i) {
                    try {
                        n = e.queryXPathAll(t, r.ancestor)
                    } catch (e) {
                        throw new Error(t + " is invalid CSS and XPath selector")
                    }
                }
                return (null === n || void 0 === n ? void 0 : n.length) ? n : void 0
            }
        }, function(e) {
            r.useForEach ? e.forEach(n) : n(e)
        }, r, i)
    }, e.waitForElement = function(t, n, r, i) {
        void 0 === r && (r = null), void 0 === i && (i = null), r = __assign({
            ancestor: document
        }, r || {}), e.waitUntil(function() {
            if (r.ancestor) try {
                return r.ancestor.querySelector(t)
            } catch (n) {
                try {
                    return e.queryXPath(t, r.ancestor)
                } catch (e) {
                    throw new Error(t + " is invalid CSS and XPath selector")
                }
            }
        }, n, r, i)
    }
}(),
function() {
    function e(e, t, r, i) {
        -1 === u.indexOf(e) && (u.push(e), n.execJs(o + t, r).then(function() {
            i && window.postMessage({
                isUserWay: !0,
                action: "remediation",
                type: "add-dynamically",
                remediationHelperName: i
            }, "*")
        }))
    }
    var t = UserWayWidgetApp.addLib("cpr_patterns_observer"),
        n = UserWayWidgetApp.getLib("util"),
        r = UserWayWidgetApp.getLib("remediation_util"),
        i = UserWayWidgetApp.getLib("remediationConfig"),
        o = (i && i.complex && i.complex, "https://cdn.userway.org/"),
        a = "widgetapp/2025-11-25-08-56-56/remediation/nav_menu_helper_1764061016441.js",
        u = [];
    t.apply = function(e) {
        l.filter(function(e) {
            return e.onPageLoad
        }).forEach(function(e) {
            return e.observe()
        })
    }, t.tick = function(e) {
        l.filter(function(e) {
            return e.onDomChanged
        }).forEach(function(e) {
            return e.observe()
        })
    };
    var l = [{
        name: "PayoneerAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/payoneer_account_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "m8nhTkGuMw" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-NJHPNbXQL8/yvJDyo23NXe1W44QtML+W756pkztQpYM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "SimplexAccountSitesCommon",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/simplex_account_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = this;
            "DBnq3tIKbX" === UserWayWidgetApp.ContextHolder.config.account && function() {
                e(t.name, t.path, "sha256-7a+7Xg3vciW+Mne1lJuwv2A4CANleNvKOmGD12pHInM=", t.remediationHelperName)
            }()
        }
    }, {
        name: "JQueryUiDatepicker",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/jqueryui_datepicker_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            [].slice.call(document.querySelectorAll(".hasDatepicker")).filter(function(e) {
                return !e.getAttribute("data-uw-rm-cpr-jqdp")
            }).length && jQuery && jQuery.ui && jQuery.ui.datepicker && e(this.name, this.path, "sha256-fzY74JVqYIY5N5yNkPCLVyawerLdVlcB7cdjZRcRfKs=", this.remediationHelperName)
        }
    }, {
        name: "slickSlider",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/slick_slider_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".slick-slider") && e(this.name, this.path, "sha256-HzbaajCSXjYzpdPrxYVWGL41xitmsBp335XXFB2zyNI=", this.remediationHelperName)
        }
    }, {
        name: "NavMenu",
        remediationHelperName: "",
        path: "//",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            var t = function() {
                window.jQuery && window.jQuery.ui && window.jQuery.ui.version ? (r.waitUntil(function() {
                    return !!(window.jQuery && window.jQuery.ui && window.jQuery.ui.version && window.jQuery.ui.menu) && !!document.querySelector(".navigation .ui-menu-item")
                }, function() {
                    setTimeout(function() {
                        e("JQueryUiMenu", "widgetapp/2025-11-25-08-56-56/remediation/jqueryui_menu_helper_1764061016441.js", "sha256-vvjYbKhSaii5P+3Ctik4H+LTSHLvHDnybHBFwUSL1uQ=", "")
                    }, 4e3)
                }, {
                    timeout: 1e4
                }), setTimeout(function() {
                    -1 === u.indexOf("JQueryUiMenu") && e("NavMenu", a, "sha256-SO73/mGj4sfIisHGomO9hRtqBTY2B+Uv0r5ORHLUIlU=", "")
                }, 14100)) : -1 === u.indexOf("JQueryUiMenu") && e("NavMenu", a, "sha256-SO73/mGj4sfIisHGomO9hRtqBTY2B+Uv0r5ORHLUIlU=", "")
            };
            "complete" === document.readyState ? t() : window.addEventListener("load", t, !1)
        }
    }, {
        name: "OwlCarousel",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/owl_carousel_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".owl-carousel") && e(this.name, this.path, "sha256-rb1LgLG5AywiZge4c4i5sFyYYqCydrhEB59/RLdR76g=", this.remediationHelperName)
        }
    }, {
        name: "yotpoWidget",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/yotpo_widget_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".yotpo") && e(this.name, this.path, "sha256-GIuAq4nuA4gneXSAeZ/QDQug8Z/6Xbz2E9fOLGZV5Eg=", this.remediationHelperName)
        }
    }, {
        name: "judgeMe",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/judgeme_widget_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".jdgm-star") && e(this.name, this.path, "sha256-UbU25H+TzYB73LKY1BZpGepuOcR3Zq40WFZ/6Bf9s3s=", this.remediationHelperName)
        }
    }, {
        name: "cycleSliderHelper",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/cycle_slider_helper_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            document.querySelector(".cycle-slide") && e(this.name, this.path, "sha256-7d6M1UDXQDlMngKZI+asQoUOXwa4BMyeRqUCiDYsxas=", this.remediationHelperName)
        }
    }, {
        name: "muiElementsRemediation",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/mui_elements_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !0,
        observe: function() {
            ["mat-expansion-panel.mat-expansion-panel", ".mat-option-text", ".mat-option-ripple", ".mat-form-field-label-wrapper", ".mat-expansion-panel-header-title", ".mat-expansion-indicator", ".mat-autocomplete-panel", ".mat-expansion-panel-header"].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-yXI4CdhFr5OhbD13f+WFeyHuPTtGa1K47eJRnqTztlI=", this.remediationHelperName)
        }
    }, {
        name: "shortPointHelper",
        remediationHelperName: "",
        path: "widgetapp/2025-11-25-08-56-56/remediation/s_p_1764061016441.js",
        onPageLoad: !0,
        onDomChanged: !1,
        observe: function() {
            ['[data-shortpoint-type="row"]'].some(function(e) {
                return document.querySelector(e)
            }) && e(this.name, this.path, "sha256-wEsvu9mmG0N5053GtFHN4cn5qmr27+xhS3MMUa3MVBM=", this.remediationHelperName)
        }
    }]
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var n = e.alt;
        if (n && n.trim()) return n.trim();
        var r = e.getAttribute("aria-label");
        if (r && r.trim()) return r.trim();
        var i = e.getAttribute("aria-describedby");
        if (i) {
            var o = t(i);
            if (o) return o
        }
        var a = e.getAttribute("aria-labelledby");
        if (a) {
            var o = t(a);
            if (o) return o
        }
        return null
    }

    function t(e) {
        var t = e.split(" "),
            n = "";
        return t.forEach(function(e) {
            e = e.trim();
            var t = document.getElementById(e);
            n += t && t.textContent ? t.textContent : ""
        }), n
    }
    var n, r = UserWayWidgetApp.addLib("remediation_utils");
    r.ignoreElementFromHelperProcessingAttr = "data-uw-rm-ignore";
    var i = UserWayWidgetApp.getLib("util"),
        o = UserWayWidgetApp.getLib("inlineStyling"),
        a = UserWayWidgetApp.getLib("xpath_search"),
        u = UserWayWidgetApp.getLib("remediation_util");
    r.PROCESS_ATTRIBUTES = {
        CER: {
            popup: {
                wrapper: "data-uw-cer-popup-wrapper",
                close: "data-uw-cer-popup-close"
            }
        }
    };
    var l = {
        attrMarker: "uw-remediation",
        className: "uw-remediation-highlighting",
        styles: (n = {
            border: "dashed 2px #c00"
        }, n["border-radius"] = "3px", n["box-shadow"] = "0 0 0 4px yellow, inset 0 0 0 4px yellow", n)
    };
    r.sendBackEnd = function(e, t, n) {
        var r = {
            method: "POST",
            url: "https://api.userway.org/api" + e,
            header: {
                "Content-Type": "application/json"
            },
            body: {
                userId: UserWayWidgetApp.ContextHolder.config.services.userId,
                siteId: UserWayWidgetApp.ContextHolder.config.services.siteId
            }
        };
        return t && (r.body.elements = t), "object" == typeof n && Object.keys(n).map(function(e) {
            r.body[e] = n[e]
        }), i.request(r)
    }, r.highlightElements = function(e, t, n) {
        var r, i, u, d, s = document.querySelectorAll("." + l.className);
        s.length && s.forEach(function(e) {
            o.resetInlineStyles(e, l.attrMarker, l.styles), e.classList.remove(l.className)
        });
        var c = [];
        switch (e) {
            case "xpath":
                var f = a.recursiveXpathSearch(t);
                c = "boolean" != typeof f ? [f] : [];
                break;
            case "href":
                var p = Array.prototype.slice.call(document.querySelectorAll("[href]"));
                try {
                    for (var m = __values(p), h = m.next(); !h.done; h = m.next()) {
                        var y = h.value;
                        y.href.toLowerCase().indexOf(t) > -1 && c.push(y)
                    }
                } catch (e) {
                    r = {
                        error: e
                    }
                } finally {
                    try {
                        h && !h.done && (i = m.return) && i.call(m)
                    } finally {
                        if (r) throw r.error
                    }
                }
                break;
            case "src":
                var g = Array.prototype.slice.call(document.querySelectorAll("[src]"));
                try {
                    for (var v = __values(g), b = v.next(); !b.done; b = v.next()) {
                        var A = b.value;
                        A.src.toLowerCase().indexOf(t) > -1 && c.push(A)
                    }
                } catch (e) {
                    u = {
                        error: e
                    }
                } finally {
                    try {
                        b && !b.done && (d = v.return) && d.call(v)
                    } finally {
                        if (u) throw u.error
                    }
                }
                break;
            case "attr":
                if (n.attrName) {
                    var _ = document.querySelectorAll("[" + n.attrName + '="' + t + '"]');
                    c = Array.prototype.slice.call(_)
                }
        }
        for (var E = 0; E < c.length; E++) {
            var w = c[E];
            if (w && "function" == typeof w.setAttribute && (w.classList.add(l.className), o.applyInlineStyles(w, l.attrMarker, l.styles), !E && n.scroll)) {
                var S = w.getBoundingClientRect(),
                    x = S.top + window.pageYOffset - document.documentElement.clientTop - window.innerHeight / 2 + S.height;
                window.scrollTo({
                    top: x,
                    behavior: "smooth"
                })
            }
        }
    }, r.getElementAccessibleName = function(n) {
        var r = n.getAttribute("aria-label"),
            i = n.getAttribute("aria-describedby");
        if (i && (r += t(i)), r && r.trim()) return r.trim().toLowerCase();
        var o = n.getAttribute("aria-labelledby");
        if (o && (r += t(o)), r && r.trim()) return r.trim().toLowerCase();
        if ((r = n.textContent ? n.textContent : null) && r.trim()) return r.trim().toLowerCase();
        if ((r = n.value || "") && r.trim() && "INPUT" === n.tagName.toUpperCase() && n.type && -1 !== ["button", "submit", "reset"].indexOf(n.type.toLowerCase())) return r.trim().toLowerCase();
        var a = n.querySelector('img, *[role="img"]');
        return a && (r = e(a)) && r.trim() ? r.trim().toLowerCase() : null
    }, r.isInertElement = function(e) {
        for (var t = e; t && t !== document.documentElement;) {
            if (t.hasAttribute("inert")) return !0;
            t = t.parentElement
        }
        return !1
    }, r.isAriaHiddenElement = function(e) {
        for (var t = e; t && t !== document.documentElement;) {
            if ("true" === t.getAttribute("aria-hidden")) return !0;
            t = t.parentElement
        }
        return !1
    }, r.hasTabbableDescendants = function(e) {
        var t, n, i = e.querySelectorAll(u.focusableElementsSelector);
        if (!i.length) return !1;
        try {
            for (var o = __values(i), a = o.next(); !a.done; a = o.next()) {
                var l = a.value;
                if (!r.isInertElement(l) && u.isElementVisible(l, {
                        shouldBeInViewport: !1
                    })) return !0
            }
        } catch (e) {
            t = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (n = o.return) && n.call(o)
            } finally {
                if (t) throw t.error
            }
        }
        return !1
    }, r.isNativeTabbableElement = function(e) {
        if (!e || !e.matches) return !1;
        try {
            return e.matches(u.focusableElementsSelector)
        } catch (e) {
            return console.warn("Invalid selector matching", e), !1
        }
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_helper_outcome"),
        t = UserWayWidgetApp.getLib("util");
    e.of = function(e, n, r, i, o) {
        return n = n || {
            items: []
        }, r = r || {
            items: [],
            path: null
        }, {
            helperName: e,
            postMessageAppData: n,
            backEndData: r,
            countFixed: i,
            countTodo: o,
            hash: t.hashString(e + JSON.stringify(n) + i + o)
        }
    }
}();
var __assign = this && this.__assign || function() {
    return __assign = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++) {
            t = arguments[n];
            for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
        }
        return e
    }, __assign.apply(this, arguments)
};
! function() {
    var e = UserWayWidgetApp.addLib("remediation_results_holder"),
        t = UserWayWidgetApp.getLib("util"),
        n = ["REMEDIATION_COLOR_CONTRAST"];
    e.instance = new function() {
        var e = this,
            r = {};
        e.reset = function() {
            r = {}
        }, e.get = function() {
            return r
        }, e.mergeHelperOutcomes = function(e, r) {
            if (e.helperName !== r.helperName) throw "Inconsistent helpers! Unable to merge " + e.helperName + " with " + r.helperName;
            var i = e.postMessageAppData && -1 === n.indexOf(e.helperName),
                o = -1 === n.indexOf(e.helperName);
            return e.postMessageAppData = i ? {
                items: e.postMessageAppData.items.concat(r.postMessageAppData.items)
            } : __assign({}, r.postMessageAppData), e.backEndData.items = r.backEndData.items, e.countFixed = o ? e.countFixed + r.countFixed : r.countFixed, e.countTodo = e.countTodo + r.countTodo, e.hash = t.hashString(r.hash), e
        }, e.put = function(t) {
            var n = t.helperName,
                i = r[n] ? e.mergeHelperOutcomes(r[n], t) : t;
            r[n] = i
        }, e.getCurrentHash = function() {
            var e = "";
            return Object.keys(r).length ? (Object.keys(r).forEach(function(t) {
                e += r[t].hash
            }), e) : e
        }, e.getHelperPostMessagePayload = function(e) {
            var t = r[e];
            return t ? t.postMessageAppData : {
                items: []
            }
        }, e.getHelpersOutcomeCounters = function() {
            var e = {};
            return Object.keys(r).forEach(function(t) {
                e[t] = r[t].countFixed
            }), e
        }, e.getHelpersTodoOutcomeCounters = function() {
            var e = {};
            return Object.keys(r).forEach(function(t) {
                e[t] = r[t].countTodo
            }), e
        }, e.toString = function() {
            return JSON.stringify(r)
        }
    }
}(),
function() {
    var e = UserWayWidgetApp.addLib("remediation_stopwatch"),
        t = {};
    e.checkPointHelperStart = function(e, n) {
        n.debugMode && (t.hasOwnProperty(e) || (t[e] = {
            start: [],
            "f-start": [],
            "f-end": [],
            "a-start": [],
            "a-end": [],
            "r-start": [],
            "r-end": [],
            end: []
        }), t[e].start.push(performance.now()))
    }, e.checkPointHelperEnd = function(e, n) {
        n.debugMode && t[e].end.push(performance.now())
    }, e.checkPointHelperFilterStart = function(e, n) {
        n.debugMode && t[e]["f-start"].push(performance.now())
    }, e.checkPointHelperFilterEnd = function(e, n) {
        n.debugMode && t[e]["f-end"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesStart = function(e, n) {
        n.debugMode && t[e]["a-start"].push(performance.now())
    }, e.checkPointHelperAwaitForResourcesEnd = function(e, n) {
        n.debugMode && t[e]["a-end"].push(performance.now())
    }, e.checkPointHelperDoRemediationStart = function(e, n) {
        n.debugMode && t[e]["r-start"].push(performance.now())
    }, e.checkPointHelperDoRemediationEnd = function(e, n) {
        n.debugMode && t[e]["r-end"].push(performance.now())
    }, UserWayWidgetApp.getHelpersPerformance = function() {
        var e = {};
        return Object.keys(t).forEach(function(n) {
            var r = t[n];
            e[n] = {
                "1_filter": [],
                "2_resources": [],
                "3_remediation": [],
                "4_total": []
            };
            for (var i = 0; i < r.start.length; i++) e[n]["1_filter"].push(r["f-end"][i] - r["f-start"][i]), e[n]["2_resources"].push(r["a-end"][i] - r["a-start"][i]), e[n]["3_remediation"].push(r["r-end"][i] - r["r-start"][i]), e[n]["4_total"].push(r.end[i] - r.start[i])
        }), t._aggregated = e, t
    }
}(),
function() {
    function e(e, t, r, i) {
        return new Promise(function(o, a) {
            var u = UserWayWidgetApp.getLib(e);
            n.checkPointHelperStart(u.name, i);
            var l = [];
            n.checkPointHelperFilterStart(u.name, i);
            try {
                l = u.filter ? u.filter(t, i) : null, n.checkPointHelperFilterEnd(u.name, i)
            } catch (e) {
                return n.checkPointHelperFilterEnd(u.name, i), n.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
            }
            n.checkPointHelperAwaitForResourcesStart(u.name, i), u.awaitForResources(l, i).then(function() {
                n.checkPointHelperAwaitForResourcesEnd(u.name, i), n.checkPointHelperDoRemediationStart(u.name, i), u.doRemediation(r, l, i).then(function() {
                    n.checkPointHelperDoRemediationEnd(u.name, i), n.checkPointHelperEnd(u.name, i), o()
                }).catch(function(e) {
                    n.checkPointHelperDoRemediationEnd(u.name, i), n.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
                })
            }).catch(function(e) {
                n.checkPointHelperAwaitForResourcesEnd(u.name, i), n.checkPointHelperEnd(u.name, i), i.debugMode && console.error(e), o()
            })
        })
    }
    var t = UserWayWidgetApp.addLib("remediation_processor"),
        n = UserWayWidgetApp.getLib("remediation_stopwatch");
    UserWayWidgetApp.getLib("remediation_utils");
    t.runHelper = function(t, n, r, i) {
        return t.then ? t : e(t, n, r, i)
    }, t.parallel = function(e, t) {
        return Promise.all(e.map(function(e) {
            return t(e)
        }))
    }, t.sequence = function(e, t) {
        return e.reduce(function(e, n) {
            return e.then(function() {
                return t(n)
            })
        }, Promise.resolve())
    }, t.series = function(e, n, r, i) {
        return t.sequence(e, function(e) {
            return t.parallel(e, function(e) {
                return t.runHelper(e, n, r, i)
            })
        }).catch(function(e) {
            i.debugMode && console.error(e)
        })
    }
}();
var __values = this && this.__values || function(e) {
    var t = "function" == typeof Symbol && Symbol.iterator,
        n = t && e[t],
        r = 0;
    if (n) return n.call(e);
    if (e && "number" == typeof e.length) return {
        next: function() {
            return e && r >= e.length && (e = void 0), {
                value: e && e[r++],
                done: !e
            }
        }
    };
    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
};
! function() {
    function e(e) {
        var t, n, r = [].slice.call(m.findAllElements(e)),
            i = r.filter(function(e) {
                var t, n, r = Array.from(e.attributes),
                    i = !1;
                try {
                    for (var o = __values(r), a = o.next(); !a.done; a = o.next()) {
                        var u = a.value,
                            l = u.value.toLowerCase();
                        if (-1 !== l.indexOf("close") || -1 !== l.indexOf("dismiss")) {
                            i = !0;
                            break
                        }
                    }
                } catch (e) {
                    t = {
                        error: e
                    }
                } finally {
                    try {
                        a && !a.done && (n = o.return) && n.call(o)
                    } finally {
                        if (t) throw t.error
                    }
                }
                return i
            }),
            o = null,
            a = l().vw,
            u = Math.round(a / 20);
        try {
            for (var d = __values(i), s = d.next(); !s.done; s = d.next()) {
                var c = s.value,
                    f = c.offsetWidth,
                    p = c.offsetHeight;
                if (f && p && f <= 5 * u) {
                    o = c;
                    break
                }
            }
        } catch (e) {
            t = {
                error: e
            }
        } finally {
            try {
                s && !s.done && (n = d.return) && n.call(d)
            } finally {
                if (t) throw t.error
            }
        }
        return o
    }

    function t(e, t) {
        var n, r, i = null;
        try {
            for (var o = __values(e[0]), a = o.next(); !a.done; a = o.next()) {
                var l = a.value,
                    d = new Array(e.length).fill(0);
                d[0] = 1;
                for (var s = 1; s < e.length; s++) {
                    e[s].indexOf(l) > -1 && (d[s] = 1)
                }
                if (d.every(function(e) {
                        return !!e
                    })) {
                    i = l;
                    break
                }
            }
        } catch (e) {
            n = {
                error: e
            }
        } finally {
            try {
                a && !a.done && (r = o.return) && r.call(o)
            } finally {
                if (n) throw n.error
            }
        }
        return i && 0 === e[0].indexOf(i) && u(i.offsetWidth, t) < 5 && (i = null), i
    }

    function n(e, t) {
        return e.classList.contains("tt-dropdown-menu") || /datepicker/.test(e.getAttribute("class")) || !!e.id && "klevuSearchingArea" === e.id || e.hasAttribute("data-uw-rm-ignore") || !!Array.from(document.querySelectorAll("nav")).find(function(t) {
            return e.contains(t)
        }) || !!e.querySelector("[class*='search']")
    }

    function r(e) {
        var t = window.getComputedStyle(e),
            r = "none" === t.display,
            i = "fixed" === t.position,
            o = parseFloat(t.width),
            a = parseFloat(t.height),
            l = u(o, document.body.offsetWidth),
            d = u(a, document.body.offsetHeight);
        return l >= 10 && d >= 10 && i && !r && o && a && !n(e, t)
    }

    function i(e) {
        var t = null;
        if (!e) return t;
        for (; e && "BODY" !== e.tagName;) {
            if (r(e)) {
                t = e;
                break
            }
            e = e.parentElement
        }
        return t
    }

    function o() {
        return /^([^.]+\.)?manage\..*userway\.(dev|org)$/.test(window.location.host)
    }

    function a() {
        if (114355 === f.services.siteId || 990479 === f.services.siteId || o()) return null;
        var e = l(),
            n = e.vw,
            r = e.vh,
            a = Math.round(n / 2),
            u = Math.round(r / 2),
            d = Math.round(3 * n / 4),
            s = Math.round(r / 4),
            c = u + Math.round(r / 4),
            p = Math.round(n / 20),
            m = Math.round(r / 20),
            h = [{
                x: a,
                y: u - m
            }, {
                x: a + p,
                y: u
            }, {
                x: a,
                y: u + m
            }, {
                x: a - p,
                y: u
            }],
            y = [{
                x: d,
                y: u - m
            }, {
                x: d + p,
                y: u
            }, {
                x: d,
                y: u + m
            }, {
                x: d - p,
                y: u
            }],
            g = [{
                x: a,
                y: s
            }, {
                x: a - p,
                y: s + m
            }, {
                x: a + p,
                y: s + m
            }],
            v = [{
                x: a,
                y: c
            }, {
                x: a - p,
                y: c - m
            }, {
                x: a + p,
                y: c - m
            }],
            b = document.elementsFromPoint(h[0].x, h[0].y),
            A = document.elementsFromPoint(h[1].x, h[1].y),
            _ = document.elementsFromPoint(h[2].x, h[2].y),
            E = document.elementsFromPoint(h[3].x, h[3].y),
            w = i(t([b, A, _, E], n));
        if (w) return w;
        var S = document.elementsFromPoint(g[0].x, g[0].y),
            x = document.elementsFromPoint(g[1].x, g[1].y),
            W = document.elementsFromPoint(g[2].x, g[2].y),
            O = i(t([S, x, W], n));
        if (O) return O;
        var C = document.elementsFromPoint(v[0].x, v[0].y),
            k = document.elementsFromPoint(v[1].x, v[1].y),
            N = document.elementsFromPoint(v[2].x, v[2].y),
            P = i(t([C, k, N], n));
        if (P) return P;
        var L = document.elementsFromPoint(y[0].x, y[0].y),
            R = document.elementsFromPoint(y[1].x, y[1].y),
            U = document.elementsFromPoint(y[2].x, y[2].y),
            H = document.elementsFromPoint(y[3].x, y[3].y),
            T = i(t([L, R, U, H], n));
        return T || null
    }

    function u(e, t) {
        return Math.abs(e - t) / ((e + t) / 2) * 100
    }

    function l() {
        return {
            vw: Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
            vh: Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0)
        }
    }
    var d = UserWayWidgetApp.addLib("cer_observer"),
        s = UserWayWidgetApp.getLib("event_emitter"),
        c = UserWayWidgetApp.getLib("remediation_utils"),
        f = UserWayWidgetApp.ContextHolder.config,
        p = UserWayWidgetApp.getLib("remediationConfig").popups,
        m = UserWayWidgetApp.getLib("util"),
        h = [];
    d.tick = function(t) {
        var n = t.processParameters;
        n.debugMode && console.log("CER observer: tick");
        var r, i = null;
        if (n.debugMode && (r = performance.now()), p.enabled && !f.tunings.new_popup_helper) {
            var o = null;
            try {
                o = a()
            } catch (e) {
                n.debugMode && console.error(e)
            }
            if (o) {
                o.setAttribute(c.PROCESS_ATTRIBUTES.CER.popup.wrapper, "");
                if (-1 === h.indexOf(o)) {
                    s.emitEvent("UW_CER_POPUP_FOUND", [o]), h.push(o);
                    var u = null;
                    try {
                        u = e(o)
                    } catch (e) {
                        n.debugMode && console.error(e)
                    }
                    u && u.setAttribute(c.PROCESS_ATTRIBUTES.CER.popup.close, ""), s.emitEvent("UW_CER_POPUP_ON", [
                        [o, u]
                    ]), n.debugMode && console.log("CER observer: POPUP found", o, u)
                }
            } else h.forEach(function(e) {
                s.emitEvent("UW_CER_POPUP_OFF", [e]), n.debugMode && console.log("CER observer: POPUP closed", e)
            }), h = []
        }
        n.debugMode && (i = performance.now(), console.log("CER observer tick: execution took " + (i - r) + " milliseconds."))
    }
}();
var __read = this && this.__read || function(e, t) {
        var n = "function" == typeof Symbol && e[Symbol.iterator];
        if (!n) return e;
        var r, i, o = n.call(e),
            a = [];
        try {
            for (;
                (void 0 === t || t-- > 0) && !(r = o.next()).done;) a.push(r.value)
        } catch (e) {
            i = {
                error: e
            }
        } finally {
            try {
                r && !r.done && (n = o.return) && n.call(o)
            } finally {
                if (i) throw i.error
            }
        }
        return a
    },
    __spreadArray = this && this.__spreadArray || function(e, t, n) {
        if (n || 2 === arguments.length)
            for (var r, i = 0, o = t.length; i < o; i++) !r && i in t || (r || (r = Array.prototype.slice.call(t, 0, i)), r[i] = t[i]);
        return e.concat(r || Array.prototype.slice.call(t))
    };
! function() {
    function e(e) {
        I && I.time(e)
    }

    function t(e) {
        I && I.timeEnd(e)
    }

    function n() {
        N.getMeasurements && N.getMeasurements("Remediation")
    }

    function r(e) {
        return e ? __spreadArray([q, j, V], __read(Y.map(function(e) {
            return [e]
        })), !1) : __spreadArray([
            ["REMEDIATION_KEYBOARD_NAVIGATION"]
        ], __read(Y.map(function(e) {
            return [e]
        })), !1)
    }

    function i() {
        B.completedEventFired || (B.completedEventFired = !0, E.fireUserWayRemediationCompletedEvent({
            enabled: !0,
            counters: k.getHelpersOutcomeCounters()
        }))
    }

    function o() {
        if (!B.iterationInProgress) {
            var e = W.consolidated && !UserWayWidgetApp.ContextHolder.remediationResources;
            if (W.consolidated || E.fireUserWayRemediationCompletedEvent({
                    enabled: !1
                }), e || D()) return void E.fireUserWayRemediationCompletedEvent({
                enabled: !1
            });
            var t = r(!B.domChangesEnqueued.length);
            B.iterationInProgress = !0, B.domChangesEnqueued = [], B.debugMode && console.log("UserWay Remediation: tick started"), w.series(t, [document.body], v.HelperCallbackAggregator, {
                reset: B.locationChanged,
                debugMode: F
            }).catch(function(e) {
                console.error(e)
            }).finally(function() {
                var e;
                B.debugMode && console.log("UserWay Remediation: tick ended"), i(), M && (S.tick({
                    processParameters: B
                }), null === (e = null === x || void 0 === x ? void 0 : x.tick) || void 0 === e || e.call(x, {
                    processParameters: B
                })), setTimeout(function() {
                    n(), s(), c(), B.iterationInProgress = !1, B.domChangesEnqueued.length && o()
                }, 1e3)
            }), B.locationChanged && f(), B.locationChanged = !1
        }
    }

    function a() {
        var n;
        G.forEach(function(n) {
            var r;
            e(n);
            var i = UserWayWidgetApp.getLib(n);
            B.debugMode && console.log("UserWay Remediation: One-time helper applied %c" + n, "color:Red"), null === (r = null === i || void 0 === i ? void 0 : i.apply) || void 0 === r || r.call(i, B), t(n)
        }), null === (n = null === x || void 0 === x ? void 0 : x.apply) || void 0 === n || n.call(x, {
            processParameters: B
        })
    }

    function u() {
        setTimeout(function() {
            o(), M && a(), B.debugMode && console.log("UserWay Remediation: process started"), b.on(P, function(e, t) {
                if (t && (!t || t.length)) {
                    if (R) return void(B.debugMode && console.log("UserWay Remediation: SKIP_DOM_CHANGES_REMEDIATION"));
                    B.debugMode && console.log("UserWay Remediation: tick resumed; initiator: DOM change"), D() || (B.domChangesEnqueued = B.domChangesEnqueued.concat(t), B.iterationInProgress || o())
                }
            })
        }, L)
    }

    function l(e) {
        var t = e.data.remediationHelperName;
        t && (V.push("REMEDIATION_" + t), K.push("REMEDIATION_" + t), o())
    }

    function d(e) {
        var t = UserWayWidgetApp.getLib("REMEDIATION_NAVIGATION_MENU");
        t && "function" == typeof t.apply && t.apply(B), U && u()
    }

    function s() {
        p("remediation-count", k.getHelpersOutcomeCounters())
    }

    function c() {
        p("all-data", k.get())
    }

    function f() {
        p("get-site-info", {
            origin: location.origin,
            path: location.pathname
        })
    }

    function p(e, t) {
        B.debugMode && (console.log("UserWay Remediation PostMessage: %c[TYPE]: %c" + e, "color:Blue", "color:Red"), console.group("%c[PAYLOAD]:", "color:Blue"), console.log(t), console.groupEnd()), E.postMessage({
            action: "remediation",
            type: e,
            data: t
        })
    }
    var m, h, y, g, v = UserWayWidgetApp.addLib("remediation_manager"),
        b = UserWayWidgetApp.getLib("event_emitter"),
        A = UserWayWidgetApp.getLib("dom_observer_v2"),
        _ = UserWayWidgetApp.getLib("remediation_utils"),
        E = UserWayWidgetApp.getLib("util"),
        w = UserWayWidgetApp.getLib("remediation_processor"),
        S = UserWayWidgetApp.getLib("cer_observer"),
        x = UserWayWidgetApp.getLib("cpr_patterns_observer"),
        W = UserWayWidgetApp.getLib("remediationConfig"),
        O = UserWayWidgetApp.ContextHolder.config,
        C = UserWayWidgetApp.getLib("remediation_util"),
        k = UserWayWidgetApp.getLib("remediation_results_holder").instance,
        N = UserWayWidgetApp.getLib("performance_logger");
    v.ResultsHolder = k;
    var P = A.DOM_OBSERVER_DOM_CHANGED_EVENT,
        L = (null === (m = null === O || void 0 === O ? void 0 : O.tunings) || void 0 === m ? void 0 : m.tech_rem_in_throttle_ms) ? Number(null === (h = null === O || void 0 === O ? void 0 : O.tunings) || void 0 === h ? void 0 : h.tech_rem_in_throttle_ms) : 1e3,
        R = null === (y = null === O || void 0 === O ? void 0 : O.tunings) || void 0 === y ? void 0 : y.tech_rem_dom,
        U = null === (g = null === O || void 0 === O ? void 0 : O.tunings) || void 0 === g ? void 0 : g.tech_rem_on_tab,
        H = document.querySelector("html"),
        T = E.isMobile(),
        I = N.getInstance ? N.getInstance("Remediation") : null,
        D = function() {
            if (location.pathname && location.pathname.indexOf("wp-admin") > -1) return !0;
            if (!W.commonSettings) return !1;
            var e = W.commonSettings,
                t = e.enabled,
                n = e.config,
                r = n.mobile,
                i = n.disabledPages;
            return !t || (!(!UserWayWidgetApp.ContextHolder.config.isMobile || !r || r.enabled) || !(null === i || void 0 === i || !i.some(function(e) {
                var t;
                return (null === (t = window.location) || void 0 === t ? void 0 : t.href.indexOf(e)) > -1
            })))
        },
        M = !!O.remediation && !D(),
        F = !1;
    try {
        UserWayWidgetApp.setDebugMode = function(e) {
            e ? (window.localStorage.setItem("userway-rm-debug", "1"), console.log("UserWay Remediation: Debug mode enabled")) : window.localStorage.removeItem("userway-rm-debug")
        }, F = window.localStorage.getItem("userway-rm-debug")
    } catch (e) {}
    var B = {
            iterationInProgress: !1,
            locationChanged: !0,
            domChangesEnqueued: [],
            completedEventFired: !1,
            debugMode: F
        },
        q = M ? ["REMEDIATION_SCREEN_READER_BASIC"] : [],
        j = M ? [function(e) {
            var t, n, r, i = !(null === (r = null === (n = null === (t = UserWayWidgetApp.ContextHolder) || void 0 === t ? void 0 : t.config) || void 0 === n ? void 0 : n.tunings) || void 0 === r ? void 0 : r.new_keyboard_nav);
            return e && i ? e : null
        }(function(e) {
            return T ? null : e
        }("REMEDIATION_KEYBOARD_NAVIGATION"))].filter(Boolean) : [],
        V = [],
        Y = [],
        G = M ? ["REMEDIATION_FOCUS_STYLE", "REMEDIATION_POPUP"] : [],
        K = [].concat(q, j, V, Y),
        X = function() {
            function n() {}
            return n.prototype.onHelperRemediationStarted = function(t) {
                e(t)
            }, n.prototype.onHelperRemediationCompleted = function(e) {
                e.backEndData && e.backEndData.items.length && _.sendBackEnd("/remediation/" + e.backEndData.path, e.backEndData.items, e.backEndData.props), k.put(e), p(e.helperName, k.getHelperPostMessagePayload(e.helperName)), t(e.helperName)
            }, n
        }();
    v.HelperCallbackAggregator = new X, (!U || function() {
        return H.hasAttribute("data-uw-w-kb")
    }() || UserWayWidgetApp.ContextHolder.config.isMobile) && u();
    var Q = {
            "get-site-info": f,
            "remediation-count": s,
            "all-data": c,
            "element-is-visible": function(e) {
                var t = JSON.parse(e.data.data),
                    n = t.elements.map(function(e) {
                        return [e, _.isElementVisible(e)]
                    });
                p("element-is-visible", {
                    key: t.key,
                    elements: n
                })
            },
            "element-highlight": function(e) {
                var t = e.data.data.type,
                    n = e.data.data.value ? e.data.data.value.toLowerCase() : "",
                    r = Object.assign({
                        scroll: !0
                    }, e.data.data.options || {});
                _.highlightElements(t, n, r)
            },
            "app-key-nav-enabled": function(e) {
                d(e)
            },
            remediation: function(e) {
                var t = e.data.type;
                k.get()[t] && p(t, k.getHelperPostMessagePayload(t))
            },
            "remediation-check": function() {
                o()
            },
            "add-dynamically": l
        },
        J = Object.assign({}, Q),
        Z = UserWayWidgetApp.getLib("REMEDIATION_FOCUS_STYLE");
    J["custom-focus-get"] = function() {
        C.waitUntil(function() {
            return "function" == typeof(null === Z || void 0 === Z ? void 0 : Z.getFocusStyle)
        }, function() {
            p("custom-focus-get", Z.getFocusStyle())
        })
    }, J["custom-focus-update"] = function(e) {
        e.data && e.data.data && C.waitUntil(function() {
            return "function" == typeof(null === Z || void 0 === Z ? void 0 : Z.updateOutlineStyle)
        }, function() {
            Z.updateOutlineStyle(e.data)
        })
    };
    var z = function(t) {
        var n = t.data || {};
        if (n.isUserWay && ("remediation" === n.action || "aria-editor" === n.action)) {
            var r = t.data.type;
            if (-1 !== Object.keys(J).indexOf(r)) {
                e(r);
                (0, J[r])(t), e(r)
            } else J.remediation(t)
        }
    };
    E.registerPostMessageListener(z)
}();